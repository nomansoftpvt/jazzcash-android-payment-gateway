package com.nouman.jazzcashlib;

public class Constants {

    public static String jazzCashResponse = "jazzCashResponse";
}
