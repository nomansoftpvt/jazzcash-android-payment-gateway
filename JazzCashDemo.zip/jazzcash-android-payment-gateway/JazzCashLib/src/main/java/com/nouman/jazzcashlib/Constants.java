package com.nouman.jazzcashlib;

import android.widget.Toast;

public class Constants {

    public static String jazzCashResponse = "jazzCashResponse";
}
